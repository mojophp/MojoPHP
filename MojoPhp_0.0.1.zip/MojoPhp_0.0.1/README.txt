
Seja bem vindo ao Mojo*PHP!

Apresentamos a voc� o Mojo*PHP, um framework para desenvolvimento de aplica��es 
web para quem ama PHP e que � focado na facilidade e na simplicidade. O Mojo*PHP 
permite que voc� desenvolva suas aplica��es de forma simples e r�pida, al�m de 
ser muito f�cil criar suas pr�prias bibliotecas para que ele atenda cada vez mais 
as suas necessidades do dia-a-dia. Tenha mais Mojo no seu trabalho!

Conhe�a os recursos do Mojo*PHP

- Desenvolvido em padr�o de projeto MVC.
- Utiliza URL's amig�veis por padr�o e o m�todo tradicional.
- N�o te obriga a aprender uma nova forma de programar.
- Compat�vel com a maioria dos helpers do CodeIgniter�.
- Open Source!

A proposta do Mojo*PHP � de ser um Framework simples e funcional, sem amarrar
as m�os do programador na hora de desenvolver suas aplica��es.

Est� em fase de franco desenvolvimento, e em breve teremos uma vers�o oficial.

Sinta-se a vontade para ajudar no desenvolvimento e na documenta��o do Mojo*PHP, 
assim a cada dia ele fica mais completo e �til!

INSTALA��O
----------

1 - Fa�a o download do Mojo*PHP para seu servidor, configure as vari�veis do arquivo
/index.php para n�o ter problemas com o caminho da instala��o.

2 - Acesse seu navegador para a instala��o e j� ter� a tela de sauda��o.

3 - Defina as configura��es do banco de dados em /app/config/database.php para
ter acesso ao seu banco de dados.

4 -Crie seus models e controllers de acordo com suas necessidades.

Enjoy!