<p><b>Arquivo interno.</b></p>
