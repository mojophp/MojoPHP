<h3><?= $titulo_pagina; ?></h3>
<p>Esta p�gina (view interna) efetua um teste com o banco de dados.</p>
<p><?= $teste_db; ?></p>