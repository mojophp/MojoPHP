<?php

if ( ! defined('BASE_PATH')) exit('Acesso negado!');

/**
 * Este arquivo foi preparado para que voc� tenha um local para definir
 * suas constantes no sistema com seguran�a. Aqui voc� dever� usar o m�todo
 * define() do PHP e n�o a classe Config().
 */