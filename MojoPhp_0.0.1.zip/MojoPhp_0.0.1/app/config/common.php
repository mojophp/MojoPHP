<?php

if ( ! defined('BASE_PATH')) exit('Acesso negado!');

Config::write('keysalt', 'yeshuahamashia');
Config::write('time_ref', 'local');